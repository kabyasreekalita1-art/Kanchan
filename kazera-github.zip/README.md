# KAZERA Website – GitHub Pages deploy

Files: `index.html` (poori website + Admin Panel), `.nojekyll`.

## 1. Firebase setup (free, 5 minute)
1. https://console.firebase.google.com → **Add project**.
2. **Build → Realtime Database → Create database** (test mode ok, rules hum neeche badlenge). Upar jo URL dikhta hai (`https://xxxx-default-rtdb.firebaseio.com`) copy karo.
3. **Build → Authentication → Get started → Email/Password → Enable**. Phir **Users → Add user** me apna admin email + strong password banao.
4. **Project settings (gear) → General → Web API Key** copy karo.
5. `index.html` me yeh line dhundo aur dono values paste karo:
   `const CFG={FB:"",KEY:""};`
6. **Realtime Database → Rules** me yeh paste karke Publish karo:

```json
{
  "rules": {
    "content": { ".read": true, ".write": "auth != null" },
    "leads": {
      ".read": "auth != null",
      "$id": {
        ".write": "auth != null || (!data.exists() && newData.child('name').isString() && newData.child('name').val().length < 100 && newData.child('msg').val().length < 2000)"
      }
    },
    "events": {
      ".read": "auth != null",
      "$id": { ".write": "auth != null || !data.exists()" }
    }
  }
}
```
Is se: sab visitors content dekh sakte hain aur form bhej sakte hain, lekin leads/analytics aur edit sirf aap (login ke baad) kar sakte ho.

## 2. GitHub Pages
1. GitHub par new repository banao (jaise `kazera-website`).
2. `index.html` aur `.nojekyll` upload karo (root me).
3. **Settings → Pages → Branch: main / root → Save**.
4. Site `https://<username>.github.io/kazera-website/` par live hogi. Custom domain bhi Pages settings me jod sakte ho.

## 3. Admin
Site ke footer me **Admin** link → Firebase me banaya email/password se login.
Direct link: `https://<your-site>/#/admin`

## Dhyan rakho
- Firebase Web API key public hoti hai, yeh normal hai; security upar ke Rules se aati hai. Rules zaroor lagao.
- Admin se upload ki gayi images chhoti karke database me save hoti hain. Bahut saari bade images ke liye image URL (ya GitHub repo me image upload karke uska link) use karo.
- Portfolio ke 4 demo links abhi private Claude links hain. Apni sites GitHub par daalne ke baad Admin → Portfolio me `link` badal do.
- Pehli baar Admin se har section ek baar **Save** karo, tab se wahi content sabko dikhega.
